# Highseas Ratings Extension
#### An extension that displays:

In the Shipyard:
- Average vote rating out of 10
- Each project's vote rating out of 10
- An AI that can generate new ideas


In the Shop:
- Estimated time to get an item from nothing
- Estimated time to get an item you cann't currently get from your current doubloon count
